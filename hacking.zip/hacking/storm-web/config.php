<?php

$CONFIG = array (
    "admin" => [
        "fullname" => "hacker", 
        "password" => "!!Jakub!!2",
    ], 
    
);

?>