$(document).ready(function() {
    var questions = [
        { 
            question: "Jaką masz płeć?", 
            type: "single", 
            options: [
                { value: "Mężczyzna", checked: false },
                { value: "Kobieta", checked: false }
            ]
        },
        { question: "Ile masz lat?", type: "text" },
        { question: "Ile wiesz o cyberbezpieczestwie?", type: "text" },
        { question: "Jestes studentem czy uczniem?", type: "text" },
        { question: "Dlaczego akurat cyberbezpieczenstwo?", type: "text" }
    ];

    // Funkcja dodająca pytania do formularza
    function addQuestions() {
        questions.forEach(function(item, index) {
            var questionHTML = `
                <div class="question">
                    <label>${item.question}</label>
                    <div class="options">
            `;
            if(item.type === "single") {
                questionHTML += `<div class="radio-options">`; // Dodaj div dla opcji jednokrotnego wyboru
                item.options.forEach(function(option, optionIndex) {
                    questionHTML += `
                        <div class="option">
                            <input type="radio" id="answer-${index + 1}-${optionIndex + 1}" name="answer-${index + 1}" value="${option.value}" ${option.checked ? "checked" : "" }>
                            <label for="answer-${index + 1}-${optionIndex + 1}">${option.value}</label>
                        </div>
                    `;
                });
                questionHTML += `</div>`; // Zamknij div dla opcji jednokrotnego wyboru
            } else if(item.type === "text") {
                if(index === 1)
                {
                    questionHTML += `
                    <input type="number" id="answer-${index + 1}" name="answer-${index + 1}" placeholder="Wprowadź odpowiedź" pattern="[0-9]*" title="Wprowadz tylko liczby" required>
                `;
                }else{
                    questionHTML += `
                    <input type="text" id="answer-${index + 1}" name="answer-${index + 1}" placeholder="Wprowadź odpowiedź" required>
                `;
                } 
            }
            questionHTML += `</div></div>`;
            $('#questions-container').append(questionHTML);
        });
    }

    // Dodanie pytań przy ładowaniu strony
    addQuestions();

    // Obsługa kliknięcia przycisku "Wyślij"
    $('#submit-btn').click(function() {
        var formData = {};
    
        // Sprawdź czy dane nie są puste
        var isValid = true;
        questions.forEach(function(item, index) {
            if(item.type === "single") {
                var selectedOption = $('input[name="answer-' + (index + 1) + '"]:checked').val();
                if(selectedOption === undefined) {
                    alert('Odpowiedź na pytanie ' + (index + 1) + ' jest wymagana.');
                    isValid = false;
                } else {
                    formData['answer-' + (index + 1)] = selectedOption;
                }
            } else {
                var answer = $('#answer-' + (index + 1)).val();
                if(answer === '') {
                    alert('Odpowiedź na pytanie ' + (index + 1) + ' jest wymagana.');
                    isValid = false;
                } else {
                    formData['answer-' + (index + 1)] = answer;
                }
            }
        });
    
        if(isValid) {
            $.ajax({
                type: 'POST',
                url: 'handler.php',
                data: {"data": formData},
                success: function(response) {
                    console.log('Dane zostały pomyślnie wysłane.');
                    console.log(response);
                    console.log(formData);
                },
                error: function(xhr, status, error) {
                    console.error('Wystąpił błąd podczas wysyłania danych:', error);
                }
            });
        } else {
            console.error('Formularz zawiera błędy. Proszę uzupełnić wszystkie pola.');
        }
    });
});